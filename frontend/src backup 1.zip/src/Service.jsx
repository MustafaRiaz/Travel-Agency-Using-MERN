function Service(){
    return (
        <div>
            <h1>Service</h1>
            <p>This is the service page</p>
        </div>
    )
}

export default Service